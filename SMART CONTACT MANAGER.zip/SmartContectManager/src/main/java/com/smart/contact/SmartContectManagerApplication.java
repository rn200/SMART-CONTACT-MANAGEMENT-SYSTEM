package com.smart.contact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartContectManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartContectManagerApplication.class, args);
	}

}
